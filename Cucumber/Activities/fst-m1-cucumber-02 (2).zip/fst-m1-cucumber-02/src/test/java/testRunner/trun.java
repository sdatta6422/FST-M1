package testRunner;

//import io.cucumber.junit.CucumberOptions;

//@CucumberOptions(
	   // features = "Features",
	   // glue = {"stepDefinitions"},
	   // tags = "@SmokeTest",
	   // plugin = {"html: test-reports"},
	   // monochrome = true
	//)


public class trun {

}
