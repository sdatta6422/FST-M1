package stepDefinitions;

import java.time.Duration;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginTestStepsActivity2 {
    WebDriver driver;
    WebDriverWait wait;
    
    @Given("the user is on the login page for activity2")
    public void loginPage() {
        //Setup instances
        driver = new FirefoxDriver();
        wait = new WebDriverWait(driver,Duration.ofSeconds(120));
        
        //Open browser
        driver.get("https://training-support.net/webelements/login-form");
    }
    
    @When("the user enters username and password for activity2")
    public void enterCredentials() {
        //Enter username
        driver.findElement(By.id("username")).sendKeys("admin");
        //Enter password
        driver.findElement(By.id("password")).sendKeys("password");
        //Click Login
       // driver.findElement(By.xpath("//button[@type='submit']")).click();
    }
    
    @And("clicks the submit button for activity2")
    public void clickSubmit() {
        // Find the submit button and click it
        driver.findElement(By.xpath("//button[text()='Submit']")).click();
        //button[@class='svelte-1pdjkmx']
    	// driver.findElement(By.xpath("//button[@class='svelte-1pdjkmx']")).click();
    }
    
    @Then("get the confirmation message and verify it for activity2")
    public void confirmMessage() {
        // Find the confirmation message
        wait.until(ExpectedConditions.textToBePresentInElementLocated(By.cssSelector("h2.mt-5"), "Welcome"));
        String message = driver.findElement(By.cssSelector("h2.mt-5")).getText();
        // Assert message
        Assertions.assertEquals("Welcome Back, Admin!", message);
    }
    
   
   
    

}