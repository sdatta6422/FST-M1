package stepDefinitions;

import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class HelloSeleniumSteps {
private WebDriver driver;
private String title;

@Given("User is on the training support homepage for helloselenium")
public void givenFunctionName() 
{
	driver=new FirefoxDriver();
	driver.get("https://training-support.net");
}

@When("the user checks the title of the page for helloselenium")
public void whenFunctionName() 
{
title=driver.getTitle();	
System.out.println(title);
}

@Then("they should see Training Support for helloselenium")
public void thenFunctionName() 
{
Assertions.assertEquals("Training Support",title);	
}

@And("close the browser for helloselenium")
public void close_the_browser()
	
	{
		driver.quit();
	}

}





