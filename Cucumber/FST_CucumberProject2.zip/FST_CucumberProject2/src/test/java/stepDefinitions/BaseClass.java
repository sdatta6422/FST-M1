package stepDefinitions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BaseClass {
    // Create a new instance of the Firefox driver
    static WebDriver driver;
    static WebDriverWait wait;
}