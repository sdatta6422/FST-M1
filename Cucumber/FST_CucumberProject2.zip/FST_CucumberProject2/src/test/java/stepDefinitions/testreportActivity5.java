package stepDefinitions;

import java.time.Duration;

import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
//import java.time.Duration;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class testreportActivity5 {
private WebDriver driver;
private String title;
private Scenario scenario;

@Before
public void setupscenario(Scenario currentscenario)
{
	scenario =currentscenario;
}

@Given("the user is on the login page for activity5")
public void openPage() {
	 //Setup instances
    driver = new FirefoxDriver();
   // wait = new WebDriverWait(driver,Duration.ofSeconds(120));
    
 // Open the login page
    driver.get("https://training-support.net/webelements/login-form");
    // Assert page title
    Assertions.assertEquals("Selenium: Login Form", driver.getTitle());
}

@When("the user enters {string} and {string} for activity5")
public void enterCredentialsFromInputs(String username, String password) {
    // Find the input fields
    WebElement usernameField = driver.findElement(By.id("username"));
    WebElement passwordField = driver.findElement(By.id("password"));
    // Clear the fields
    usernameField.clear();
    passwordField.clear();
    // Find username field and enter username
    usernameField.sendKeys(username);
    // Find password field and enter password
    passwordField.sendKeys(password);
}


@And("clicks the submit button for activity5")
public void clickSubmit() {
    // Find the submit button and click it
    driver.findElement(By.xpath("//button[text()='Submit']")).click();
}

@Then("get the confirmation text and verify message as {string} for activity5") 
public void confirmMessageAsInput(String expectedMessage) {
	// Find the confirmation message
   // wait.until(ExpectedConditions.textToBePresentInElementLocated(By.cssSelector("h2.mt-5"), "Welcome"));
    String message = driver.findElement(By.cssSelector("h2.mt-5")).getText();
    // Assert message
    Assertions.assertEquals(expectedMessage, message);
    
    
}

@And("they should get the confirmation message screen screenshot")
public void see_confirmation_msg_screen()

{
try
{
	byte[] screenshot =((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
			String screenshotName = scenario.getName().replaceAll("","_");
	scenario.attach(screenshot,"image/png",screenshotName);
}
catch(Exception e)
{
e.printStackTrace();	
}
}
			






@And("close the browser for activity5")
public void close_the_browser()
	
	{
		driver.quit();
	}

}





